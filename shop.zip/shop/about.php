
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>About Us</title>
	<link rel="stylesheet" href="style2.css">
</head>
<body>

<nav>
  <ul>
    <li><a href="index.PHP">Home</a></li>
    <li><a href="About.php">About</a></li>
    <li><a href="contact.php">Contact</a></li>
  </ul>
</nav>
  
<br>
<header>

<h1 align = "center">About us</h1>

<p align ="left">
 eh w hon mnktob men n7na w sho hdaf l store whek...
</p>

		

	</header>	
</body>
</html>
